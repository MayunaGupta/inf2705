#include <stdlib.h>
#include <iostream>
#include <glm/gtx/io.hpp>
#include <vector>
#include <iterator>


int main(){
std::cout<<"hello";
std::cout<<glm::vec3(6);
return 0;
}
